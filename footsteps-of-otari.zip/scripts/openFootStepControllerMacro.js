game.modules.get('footsteps-of-otari')?.api?._openFootstepsController()
